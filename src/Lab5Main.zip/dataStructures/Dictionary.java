
package dataStructures;

public interface Dictionary
{
   public Object get(Object key);
   public Object put(Object key, Object theElement);
   public Object remove(Object key);
}
