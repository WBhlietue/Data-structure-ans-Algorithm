

/** interface for iterable linear lists */

package dataStructures;

import java.util.*;

public interface IterableLinearList
                 extends LinearList, Iterator
   {}
