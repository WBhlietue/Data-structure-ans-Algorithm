package UITools;

public interface IUIListener {
    public void OnClick();
}
