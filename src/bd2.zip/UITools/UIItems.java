package UITools;

import java.awt.*;
import javax.swing.*;

public class UIItems {
    protected Font f = new Font("Arial", Font.PLAIN, 20);
}
